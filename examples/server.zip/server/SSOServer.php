
<?php

use Jasny\ValidationResult;
use Jasny\SSO;

class SSOServer extends SSO\Server {
 
    static $brokers = array(
        'siakad' => array('secret'=>'siakad123'),
        'sidos' => array('secret'=>'sidos123'),
    );

    /**
     * Get the API secret of a broker and other info
     *
     * @param string $brokerId
     * @return array
     */
    // not private, protected & public or nor both is oke 
    protected function getBrokerInfo($brokerId){
        if(isset(self::$brokers[$brokerId])){
            return self::$brokers[$brokerId];
        }
        return null;
    }
    
    /**
     * Get the user information
     *
     * @return array
     */
     // not private, protected & public or nor both is oke 
    protected function getUserInfo($username){
        require "koneksi_user.php";

        $table_2 = $koneksi->query("SELECT * from TB_USER");

        while($row = $table_2->fetch_assoc()){
            $uname= $row ['username'];
            $fullname = $row ['fullname'];
            $email = $row ['email'];
            $role = $row ['role'];
            $password = $row ['password'];
            
            $usr = [ $uname => ['fullname' => $fullname, 'email' => $email, 'role'  => $role, 'password' => $password] ];

            $arr_keys = array_keys($usr);
            foreach($arr_keys as $arr){
                $arrs= [$arr];
                for($z=0;$z<count($arrs);$z++){
                    if($username == $arrs[$z]){
                        $username = $arrs[$z];
                        $users[$username] =  ['fullname' => $fullname, 'email' => $email, 'role'  => $role, 'password' => $password];
                        if(isset($users[$username])){
                            $user = compact('username')+$users[$username];
                            unset($user['password']);
                            print_r ($user);
                        }
                    }
                }
            }

        }
    }

    /**
     * Authenticate using user credentials
     *
     * @param string $username
     * @param string $password
     * @return ValidationResult
     */
     // not private, protected & public or nor both is oke 
     protected function authenticate($username, $password){
        require "koneksi_user.php";

        $table_2 = $koneksi->query("SELECT * from TB_USER");
        
        while($row = $table_2->fetch_assoc()){
            $uname= $row ['username'];
            $fullname = $row ['fullname'];
            $email = $row ['email'];
            $role = $row ['role'];
            $passwd = $row ['password'];

            $users = array( $uname => ['fullname' => $fullname, 'email' => $email, 'role'  => $role, 'password' => $passwd] );

            if (empty($username)) {
                return ValidationResult::error("Username tidak ditemukan");
            }else{
                return ValidationResult::success("Sukses!");
            }
            if (empty($password)) {
                return ValidationResult::error("Password tidak ditemukan");
            } else{
                return ValidationResult::success("Sukses!");
            }
        
            $uname = $username;
            if (empty($users[$username])) {
                return ValidationResult::error("Kredensial tidak valid!");
            }else{
                return ValidationResult::success("Sukses!");
            }

            $arr_col_passwd = array_column($users, 'password');
            $arrs[] = $arr_col_passwd;
        }
        foreach($arrs as $arr){
            for($i=0;$i<count($arr);$i++){
                if (!password_verify($password, $arr[$i])) {
                    return ValidationResult::error("Kredensial tidak valid!");
                }else{
                    return ValidationResult::success("Sukses!");
                }
            }
        }
    }
}
